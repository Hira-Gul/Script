import os
import shutil
import cv2

# Paths to directories
image_dir = r'F:\3.Dataset_2k\images'
text_dir = r'F:\3.Dataset_2k\texts'
correct_image_dir = r'F:\3.Dataset_2k\Correct\images'
correct_text_dir = r'F:\3.Dataset_2k\Correct\texts'
problematic_image_dir = r'F:\3.Dataset_2k\Problametic\images'
problematic_text_dir = r'F:\3.Dataset_2k\Problametic\texts'

# Create directories if they don't exist
os.makedirs(correct_image_dir, exist_ok=True)
os.makedirs(correct_text_dir, exist_ok=True)
os.makedirs(problematic_image_dir, exist_ok=True)
os.makedirs(problematic_text_dir, exist_ok=True)

# List of image filenames
image_filenames = os.listdir(image_dir)

for image_filename in image_filenames:
    image_path = os.path.join(image_dir, image_filename)
    text_filename = f"{os.path.splitext(image_filename)[0]}.txt"
    text_path = os.path.join(text_dir, text_filename)
    
    # Check if text file exists
    if not os.path.exists(text_path):
        print(f"Text file not found for {image_filename}, marking as problematic.")
        shutil.move(image_path, os.path.join(problematic_image_dir, image_filename))
        continue

    # Open image using OpenCV
    image = cv2.imread(image_path)
    cv2.imshow('Image', image)

    # Read and print text content
    try:
        with open(text_path, 'r', encoding='utf-8-sig') as file:
            text_content = file.read()
    except UnicodeDecodeError:
        print(f"Error reading text file for {image_filename}, marking as problematic.")
        shutil.move(image_path, os.path.join(problematic_image_dir, image_filename))
        shutil.move(text_path, os.path.join(problematic_text_dir, text_filename))
        cv2.destroyAllWindows()
        continue

    print(f"Text for {image_filename}:\n{text_content}")

    key = cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Check user input
    if key == ord('q'):
        # Correct data, move to correct_data folder
        shutil.move(image_path, os.path.join(correct_image_dir, image_filename))
        shutil.move(text_path, os.path.join(correct_text_dir, text_filename))
    elif key == ord('p'):
        # Problematic data, move to problematic folder
        shutil.move(image_path, os.path.join(problematic_image_dir, image_filename))
        shutil.move(text_path, os.path.join(problematic_text_dir, text_filename))
    else:
        print("Invalid key pressed, skipping the file.")

print("Data verification complete.")
